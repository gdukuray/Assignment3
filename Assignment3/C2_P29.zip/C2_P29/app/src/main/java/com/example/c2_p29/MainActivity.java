package com.example.c2_p29;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.text.Editable;
import android.text.TextWatcher;

public class MainActivity extends AppCompatActivity {
    private TextView label_str;
    private TextView label_ban;
    private TextView label_car;
    private TextView label_broc;
    private TextView label_alm;
    private EditText txtStr;
    private EditText txtBan;
    private EditText txtCar;
    private EditText txtBroc;
    private EditText txtAlm;
    private Button btnCalc;
    private TextView txtTotal;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtStr = (EditText) findViewById(R.id.txtStr);
        txtBan = (EditText) findViewById(R.id.txtBan);
        txtCar = (EditText) findViewById(R.id.txtCar);
        txtBroc = (EditText) findViewById(R.id.txtBroc);
        txtAlm = (EditText) findViewById(R.id.txtAlm);
        btnCalc = (Button) findViewById(R.id.btnCalc);
        txtTotal = (TextView) findViewById(R.id.txtTotal);

        btnCalc.setOnClickListener(new View.OnClickListener() {
                                       @Override
                                       public void onClick(View v) {
                                           //calculate calories
                                           String strawStr = txtStr.getText().toString();
                                           String banStr = txtBan.getText().toString();
                                           String carStr = txtCar.getText().toString();
                                           String brocStr = txtBroc.getText().toString();
                                           String almStr = txtAlm.getText().toString();
                                           TextView txtTotal = (TextView) findViewById(R.id.txtTotal);

                                           try {
                                               int strawInt = Integer.parseInt(strawStr);
                                               int strCal = 4;
                                               int banInt = Integer.parseInt(banStr);
                                               int banCal = 105;
                                               int carInt = Integer.parseInt(carStr);
                                               int carCal = 41;
                                               int brocInt = Integer.parseInt(brocStr);
                                               int brCal = 50;
                                               int almInt = Integer.parseInt(almStr);
                                               int almCalc = 163;

                                               int total = (strawInt * strCal + banInt * banCal + carInt * carCal + brocInt * brCal + almInt * almCalc);
                                               txtTotal.setText(Integer.toString(total));
                                           } catch (NumberFormatException nfe) {
                                               Toast.makeText(MainActivity.this, "Fill All Fields", Toast.LENGTH_SHORT).show();
                                           }
                                       }
                                   }
        );
    }

}


