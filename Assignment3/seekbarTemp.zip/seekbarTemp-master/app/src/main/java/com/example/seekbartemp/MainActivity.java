package com.example.seekbartemp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button submitButton;
    SeekBar simpleSeekBar;
    SeekBar simpleSeekBar1;

    private static final String MyFlag = "LECT2_FLAG";  //this will be our trail of breadcrumbs for logging events.
    private static int eventCount = 0;


    private Button btnCtoF;
    private EditText txtC;
    private EditText txtF;

    private Button btnFtoC;
    private EditText txt1C;
    private EditText txt1F;

    private double progressChangedValue;
    private double progressChangedValue1;
    private String cold;
    private String notcold;

    TextView textView;
    TextView textView1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        eventCount++;
        Log.i(MyFlag, intToStr(eventCount) + ": Activity onCreate State Transition");        setContentView(R.layout.activity_main);
        setContentView(R.layout.activity_main);
        textView1 = (TextView) findViewById(R.id.ctext); //set text for text view
        textView = (TextView) findViewById(R.id.ftext); //set text for text view
        // initiate  views
        txtC = (EditText) findViewById(R.id.txtC);
        txtF = (EditText) findViewById(R.id.txtF);
        cold = getResources().getString(R.string.itscold);
        notcold = getResources().getString(R.string.itsnotcold);
        simpleSeekBar=(SeekBar)findViewById(R.id.simpleSeekBar);
        // perform seek bar change listener event used for getting the progress value
        simpleSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
//            double progressChangedValue = 0;
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                progressChangedValue = progress;
                Double DegC, DegF;
                String F;
                DegC = progressChangedValue;
                DegF = DegC*9.0/5.0 + 32;   //todo, dblcheck formula.
                F = DegF.toString();
                txtF.setText(F);
                txtC.setText(DegC.toString());

            }

            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                if (progressChangedValue < 12)
                    Toast.makeText(getBaseContext(),cold, Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(getBaseContext(),notcold, Toast.LENGTH_LONG).show();
            }
        });
        simpleSeekBar1=(SeekBar)findViewById(R.id.simpleSeekBar1);
        // perform seek bar change listener event used for getting the progress value
        simpleSeekBar1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            //            double progressChangedValue = 0;
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                progressChangedValue1 = progress;
                Double DegC1, DegF1;
                String C;
                DegF1 = progressChangedValue1;
                System.out.println(DegF1);
                DegC1 = (DegF1-32)*5.0/9.0;   //todo, dblcheck formula.
                C = DegC1.toString();
                System.out.println(C);
                txtC.setText(C);
                txtF.setText(DegF1.toString());

            }

            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                if (progressChangedValue1 < 53)
                    Toast.makeText(getBaseContext(), cold, Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(getBaseContext(), notcold, Toast.LENGTH_LONG).show();
            }
        });
    }



    @Override
    protected void onPause() {
        super.onPause();
        Log.i(MyFlag, ": Activity onPause State Transition");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i(MyFlag, ": Activity onStop State Transition");
    }

    public void onButtonClick(View v) {
        return;
    }


    @Override
    protected void onDestroy() {
        eventCount++;
        Log.i(MyFlag, intToStr(eventCount) + ": Activity onDestroy State Transition");
        super.onDestroy();
    }
    //
    @Override
    protected void onResume() {
        eventCount++;
        Log.i(MyFlag, intToStr(eventCount) + ": Activity onRestoreInstanceState State Transition");
        super.onResume();
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i(MyFlag, "onStart: ");

    }

    //Handy Helpers...
    public String intToStr(Integer i)
    {
        Log.i(MyFlag, "converting: " + i.toString());
        return i.toString();
    }

    public int strToInt(String S)
    {
        return Integer.parseInt(S);
    }


}

