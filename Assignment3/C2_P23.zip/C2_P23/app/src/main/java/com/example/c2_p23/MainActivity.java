package com.example.c2_p23;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView txtTraffic;
    private Button btnGo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtTraffic = (TextView) findViewById(R.id.txtTraffic);
        btnGo = (Button) findViewById(R.id.btnGo);


    }

    public void traffic(View view) {
        txtTraffic = (TextView) findViewById(R.id.txtTraffic);


        ColorDrawable cd = (ColorDrawable) txtTraffic.getBackground();
        int current_color = cd.getColor();

        if(current_color == Color.parseColor("#FF0000")){
            txtTraffic.setBackgroundColor(Color.YELLOW);
        }
        else if(current_color == Color.parseColor("#FFFF00")){
            txtTraffic.setBackgroundColor(Color.GREEN);
        }
        else{
            txtTraffic.setBackgroundColor(Color.RED);
        }

    }
}